const App = () => {
    return <>
        <div className='wawl-border wawl-border-gray-200 wawl-p-5'>
            <h3 className='wawl-font-bold wawl-text-xl'>Wishlist Settings</h3>
        </div>
    </>
}

export default App;